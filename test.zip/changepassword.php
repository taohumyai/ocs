<?php 
session_start();


$password1 = $_POST['password1'];
$password2 = $_POST['password2'];
$password3 = $_POST['password3'];


$servername = "localhost";
$username = "root";
$password = "cnecnecne";
$dbname = "test";

$userid = $_SESSION['id'];

$conn = new mysqli($servername, $username, $password, $dbname);


    if($password1 ==  $_SESSION['password']){
        if($password2 == $password3){
             $sql = "UPDATE `user` SET `password`='$password2' WHERE id= $userid  ";
        }
        else
        {
            echo ("<script LANGUAGE='JavaScript'>
            window.alert('รหัสไม่ตรงกัน');
            window.location.href='changepasswordfrom.php';
            </script>");
        }   
    }
    else{
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('รหัสผ่านเดิมไม่ถูกต้อง');
        window.location.href='changepasswordfrom.php';
        </script>");
    }



 
$result = $conn->query($sql);

if ($result == 1) {
    echo ("<script LANGUAGE='JavaScript'>
        window.alert('เปบี่ยนรหัสผ่านสำเร็จ');
        window.location.href='updateuserfrom.php';
        </script>");
} else {
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('ไม่สำเร็จ');
        window.location.href='changepasswordfrom.php';
        </script>");
}


?>