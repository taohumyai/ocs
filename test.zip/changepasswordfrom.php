<!DOCTYPE html>
<html lang="en">

<head>
    <title>เปลี่ยนรหัสผ่าน</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="inner-bg">
                <div class="container">
            <h3 style="text-align:center">เปลี่ยนรหัสผ่าน</h3>
            <form action="changepassword.php" method="post">
                <div>
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label>รหัสผ่านเดิม:</label>
                    <input type="password" class="form-control" name="password1" >
                </div>
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label>รหัสผ่านใหม่:</label>
                    <input type="password" class="form-control" name="password2" >
                </div>
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label>ยืนยันรหัสผ่านใหม่:</label>
                    <input type="password" class="form-control" name="password3" >
                </div>
                <div  style="text-align:center" >
                    </br>
                    <button type="submit" class="btn btn-success">ตกลง</button>
                    <a href="updateuserfrom.php" class="btn btn-danger">ยกเลิก</a>
                </div>
                </div>
            </form>
        </div>
    </div>

</body>

</html>