<?php 
session_start();

$id = $_POST["username"]; 
$pas = $_POST['password'];


$servername = "localhost";
$username = "root";
$password = "cnecnecne";
$dbname = "test";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `user` WHERE username = '$id' && password = '$pas' ";

$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    if($row['status'] == 'admin'){
        $_SESSION['id'] = $row['id'];
         $_SESSION['password'] = $row['password'];
         $_SESSION['username'] = $row['username'];
         $_SESSION['fristname'] = $row['fristname'];
         $_SESSION['lastname'] = $row['lastname'];
         $_SESSION['address'] = $row['address'];
         $_SESSION['phone'] = $row['phone'];

         
    }else{
         $_SESSION['id'] = $row['id'];
         $_SESSION['password'] = $row['password'];
         $_SESSION['username'] = $row['username'];
         $_SESSION['fristname'] = $row['fristname'];
         $_SESSION['lastname'] = $row['lastname'];
         $_SESSION['address'] = $row['address'];
         $_SESSION['phone'] = $row['phone'];
         header( "location: updateuserfrom.php" );
     
    }

}
if ($result->num_rows > 0) {
	   echo "<script>window.open('view_users.php','_self')</script>";
} else {

    echo ("<script LANGUAGE='JavaScript'>
    window.alert('ไม่สำเร็จ');
    window.location.href='index.php';
    </script>");
}

?>