<!DOCTYPE html>
<html lang="en">
<style>Body{background-image:url(https://www.mx7.com/i/077/WTIGtF.jpg);background-position: center;background-repeat: no-repeat;background-attachment: fixed;background-color: color code;}</style>
<head>
    <title>CNE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
            <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                        	<div class="form-top">
                        	  <div class="form-top-left">
                       			  <center><h1> -:CNE58:-
                        		</h1> <br>
                                 <h2>กรุณา Login เพื่อเข้าสู่ระบบ</h2> ​ <i class="fa fa-user-secret"></i> 
                        		</div>
                        	</div>
            <form action="login.php" method="post">
                
				<fieldset>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input class="form-control" placeholder="ชื่อผู้ใช้งาน" name="username" type="text" autofocus required> 
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input class="form-control" placeholder="รหัสผ่าน" name="password" type="password" required>
                              </div>  <br>
                <button type="submit" class="btn btn-info btn-block btn-flat"><i class="fa fa-user fa-fw" aria-hidden="true"></i> ล็อกอิน</font></button> 

                <a href="registerfrom.php" class="btn btn-danger animated flash btn-block" id="idEULA" role="button" class="fa fa-pencil fa-fw" aria-hidden="true"></i> สมัครสมาชิก</a>
            </form>
        </div>
    </div>
<div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        	<center><h3><i class="fa fa-facebook-square"></i>  ติดต่อเรา</h3>
                        	<div class="social-login-buttons">
	                        	<center><h3><a class="btn btn-link-1 btn-link-1-facebook" href="https://www.m.me/t4o.it" target = "_blank">
	                        		<button type="button" class="btn btn-primary btn-lg"><i class="fa fa-facebook"></i>Facebook</button>
</body>

</html>