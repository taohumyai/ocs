<?php 

$id = $_POST["username"]; 
$pas = $_POST['password'];
$name = $_POST['fristname'];
$lname = $_POST['lastname'];
$address = $_POST['address'];
$phone = $_POST['phone'];

$servername = "localhost";
$username = "root";
$password = "cnecnecne";
$dbname = "test";


$conn = new mysqli($servername, $username, $password, $dbname);

if($id && $pas ){
    $sql = "INSERT INTO `user`(`id`, `username`, `password`, `fristname`, `lastname`, `address`, `phone`,`status`) VALUES ('','$id','$pas','$name','$lname','$address','$phone','user')";
}else{
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('สมัครไม่สำเร็จ');
    window.location.href='registerfrom.php';
    </script>");
}



$result = $conn->query($sql);

if ($result == 1) {
   echo ("<script LANGUAGE='JavaScript'>
    window.alert('สำเร็จ');
    window.location.href='index.php';
    </script>");
} else {
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('สมัครไม่สำเร็จ');
    window.location.href='registerfrom.php';
    </script>");
}


?>