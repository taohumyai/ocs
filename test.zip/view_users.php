<style>Body{background-image:url(https://www.mx7.com/i/077/WTIGtF.jpg);background-position: center;background-repeat: no-repeat;background-attachment: fixed;background-color: color code;}</style>
<html lang="en">
<head>
    <title>view user</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>

<body>

<div class="container">
    <h1 align="center">View User</h1>

<div class="jumbotron""><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>User Id</th>
            <th>User Name</th>
            <th>Password</th>
			<th>Firstname</th>
			<th>Lastname</th>
            <th>Address</th>
			<th>Call</th>
			
            <th>Delete User</th>
        </tr>
        </thead>

        <?php
        include("database/db_conection.php");
        $view_users_query="SELECT * FROM `user`";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.

        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
            $id=$row[0];
			$username=$row[1];
            $password=$row[2];
            $firstname=$row[3];
            $lastname=$row[4];
			$address=$row[5];
			$phone=$row[6];
			
			



        ?>

        <tr>
<!--here showing results in the table -->
            <td><?php echo $id;  ?></td>
			<td><?php echo $username;  ?></td>
            <td><?php echo $password;  ?></td>
            <td><?php echo $firstname;  ?></td>
            <td><?php echo $lastname;  ?></td>
			<td><?php echo $address;  ?></td>
			<td><?php echo $phone;  ?></td>
			
            <td><a href="delete.php?del=<?php echo $id ?>"><button class="btn btn-danger">Delete</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->
        </tr>

        <?php } ?>

    </table>
        </div>
</div>
<div  style="text-align:center" >
                    </br>
                    
                    <a href="changepasswordfrom.php" class="btn btn-primary">Change Pass</a>
                    <a href="index.php" class="btn btn-danger">Log out</a>
                </div>

</body>

</html>
