<?php


$dbcon=mysqli_connect("206.189.80.113","root","cnecnecne");

mysqli_select_db($dbcon,"test");

?>