<?php


$dbcon=mysqli_connect("localhost","root","cnecnecne");

mysqli_select_db($dbcon,"test");

?>