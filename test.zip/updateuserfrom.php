<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<style>Body{background-image:url(https://www.mx7.com/i/077/WTIGtF.jpg);background-position: center;background-repeat: no-repeat;background-attachment: fixed;background-color: color code;}</style>
<head>
    <title>ข้อมูลผู้ใช้งาน</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
    
	<div class="inner-bg">
                <div class="container">
            <h3 style="text-align:center">ข้อมูลผู้ใช้</h3>
            <form action="updateuser.php" method="post">
                <div>
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label >Username:</label>
                    <input type="text" class="form-control" name="username" value='<?php echo $_SESSION['username'];  ?>' disabled>
                </div>
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label>ชื่อ:</label>
                    <input type="text" class="form-control" name="fristname"  value ='<?php echo $_SESSION['fristname']; ?>'>
                </div> 
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label>นามสกุล:</label>
                    <input type="text" class="form-control" name="lastname" value ='<?php echo $_SESSION['lastname']; ?>'>
                </div>
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label>ที่อยู่:</label>
                    <input type="text" class="form-control" name="address" value ='<?php echo $_SESSION['address']; ?>'>
                </div>
                <div class="form-group" style="width: 320px;margin: 0 auto;">
                    <label>เบอโทรศัพท์:</label>
                    <input type="text" class="form-control" name="phone" value ='<?php echo $_SESSION['phone']; ?>'>
                </div>
                <div  style="text-align:center" >
                    </br>
                    <button type="submit" class="btn btn-warning" onclick="return RemoveProduct();" >บันทึกการแก้ไข</button>
                    <a href="changepasswordfrom.php" class="btn btn-primary">เปลี่ยนรหัสผ่าน</a>
                    <a href="index.php" class="btn btn-danger">ออกจากระบบ</a>
                </div>

                </div>
               
            </form>
        </div>
    </div>

</body>
<script>

  function RemoveProduct() {
  if (confirm("ยืนยันการแก้ไข ?")) {
    return true;
  } else {
    return false;
  }
}

</script>
</html>