<?php 
session_start();


$name = $_POST['fristname'];
$lname = $_POST['lastname'];
$address = $_POST['address'];
$phone = $_POST['phone'];

$servername = "206.189.80.113";
$username = "root";
$password = "cnecnecne";
$dbname = "test";

$userid = $_SESSION['id'];

$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "UPDATE `user` SET `fristname`=' $name',`lastname`='$lname',`address`='$address',`phone`='$phone' WHERE id= $userid  ";
 
$result = $conn->query($sql);

if ($result == 1) {
   echo ("<script LANGUAGE='JavaScript'>
    window.alert('สำเร็จ');
     window.location.href='updateuserfrom.php';
    </script>");
        $_SESSION['fristname'] = $name;
         $_SESSION['lastname'] = $lname;
         $_SESSION['address'] = $address;
         $_SESSION['phone'] = $phone;
} else {
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('ไม่สำเร็จ');
    window.location.href='updateuserfrom.php';
    </script>");
}


?>