<center>
<body>

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
	 <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">โหลด Config.ovpn</h1>
            
            <p><a href="http://150.95.26.217:81/client.ovpn" class="btn btn-danger"><i class="fa fa-download fa-fw"></i> โหลด Config Sv.TH</a>              </p>
            <p><a href="http://150.95.26.217:81/client.ovpn" class="btn btn-warning"><i class="fa fa-download fa-fw"></i> โหลด Config Sv.SG</a></p>  
                    </div>
            
            </div>
    </div>
</div>

</body>
</center>
<div class="footer">
	<p>© 2017 TAOTATO. All Rights Reserved | Design by <a href = "https://www.facebook.com/messages/t/t4o.it" target = "_blank">TAO</a></p>
</div>
    <script src="../asset/js/sb-admin-2.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
</body>
</html>
