<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">รายชื่อเซิร์ฟเวอร์</h1>
            <div class="dropdown pull-right">
			  <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-plus fa-fw"></span>เติมเงิน/แจ้งการโอน</button>
				<ul class="dropdown-menu">
					<li class="active"><a href="<?= base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/addsaldo-via-req') ?>">ผ่าน True Wallet</a></li>
					 
				</ul>
            </div>
            
        </div>
    </div>
    <div class="row">
       <div class="col-xs-6 col-md-5 col-md-4 col-lg-3">
            <div class="well">ยอดเงินคงเหลือ : <B><?= $user -> saldo ?></B></div>
        </div>
    </div>
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
        <?php foreach($server as $row): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <b><center><?= $row['ServerName']?> <?php if ($row['Status']) { echo '';} else {echo "(เซิฟเวอร์เต็ม)";}?></center></b>
                    </div>
                    <b><table class="table">
                        <tr>
                            <p><td width="101">  ที่อยู่เซิฟเวอร์</td><td width="104"><button type="button" class="btn btn-danger btn-xs"><?= $row['Location']?></button></p></td>
                        </tr>
                        <tr>
                            <td>  โฮสต์</td>
                            <p><td><button type="button" class="btn btn-warning btn-xs">x.x.x.x</button></p></td>
                        </tr>
                        <tr>
                            <td>  Squid Proxy</td>
                            <p><td><button type="button" class="btn btn-primary btn-xs">8080,3128</button></p></td>
                        </tr>
                        <tr>
                            <p><td>  Dropbear Port</td><td><button type="button" class="btn btn-success btn-xs"><?= $row['Dropbear']?></button></p></td>
                        </tr>
                        <tr>
                            <p><td>  OpenSSH</td><td><button type="button" class="btn btn-info btn-xs"><?= $row['OpenSSH']?></button></p></td>
                        </tr>
                        
                        <tr>
                            <p><td>  จำกัดเชื่อมต่อ</td><td><button type="button" class="btn btn-danger btn-xs"><?= $row['MaxUser']?> บัญชี/เครื่อง</button></p></td>
                        </tr>
                        <tr>
                            <p><td>  ใช้งานได้</td><td><button type="button" class="btn btn-info btn-xs"><?= $row['Expired']?> วัน</button></p></td>
                        </tr>
                            
                        <tr>
                            <p><td>  ราคา</td><td><button type="button" class="btn btn-primary btn-xs"><?= $row['Price']?> บาท</button></p></td>
                        </tr>
                       </table></b>
                    <div class="panel-footer text-center">
                        <a href="<?= base_url('panel/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-danger"><i class="fa fa-shopping-cart fa-fw"></i> เช่าเซิฟนี้</a>
                          <a href="<?= base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/addsaldo-via-hp') ?>" class="btn btn-warning"><i class="fa fa-download fa-fw"></i> โหลด Config</a></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="footer">
	<p>© 2017 TAOTATO. All Rights Reserved | Design by <a href = "https://www.facebook.com/messages/t/t4o.it" target = "_blank">TAO</a></p>
</div>
    <script src="../asset/js/sb-admin-2.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
</body>
</html>
