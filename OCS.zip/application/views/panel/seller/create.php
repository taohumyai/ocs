<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">สร้างบัญชี</h1>
        </div>
    </div>
    <div class="row">
       <div class="col-xs-6 col-md-5 col-md-4 col-lg-3">
            <div class="well">ยอดเงินคงเหลือ : <B><?php if (isset($user->saldo)) {echo $user->saldo; }?></B></div>
        </div>
    </div>
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
           <div class="col-sm-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <b><?= $server->ServerName ?></b>
                    </div>
                    <div class="panel-body">
					<?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
					<?php endif;?>
					<?= form_open() ?>
						<div class="form-group">
							<label for="username">User Name </label>
							<input type="text" name="username" class="form-control" id="username" placeholder="ตั้งชื่อผู้ใช้"/>
						</div>
						<div class="form-group">
							<label for="password">Password </label>
							<input type="text" name="password" id="password" class="form-control" placeholder="ตั้งรหัสผ่าน"/>
						</div>
                    
                    </div>
                    <div class="panel-footer text-center">
                    <input type="submit" class="btn btn-primary" value="ยืนยัน"/>
                    </form>
                </div>
            </div>
    </div>
</div>

<div class="footer">
	<p>© 2017 TAOTATO. All Rights Reserved | Design by <a href = "https://www.facebook.com/messages/t/t4o.it" target = "_blank">TAO</a></p>
</div>
    <script src="../asset/js/sb-admin-2.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
</body>
</html>
