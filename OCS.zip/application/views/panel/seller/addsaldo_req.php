<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
	 <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">เติมเงินผ่าน True wallet</h1>
            <div class="well">ยอดเงินคงเหลือ : <B><?php if (isset($user->saldo)) {echo $user->saldo; }?></B></div>
        </div>
    </div>
    <div class="row">
		  <div class="col-sm-6">
			   
			  <font color="#000000"><p class="text-info">รายละเอียดดังต่อไปนี้:: </p>
			   <p class="text-info">1.โอนเงินเสร็จ แคปหน้าโอนเงิน </p>
			   <p class="text-info">2.ส่งหลักฐานการโอนเงิน <font color="red"> <a href = "https://www.facebook.com/messages/t/t4o.it" target = "_blank">>>ที่นี่<<</a></font> เสร็จแล้วแจ้งการโอนเงินในหน้านี้  *ขอให้ความสุขจงสถิตอยู่กับทุกๆท่าน*</p>
               
               
               <p class="text-muted">หมายเหตุ: หากคุณได้ชำระเงินแล้วโปรดคลิกที่ยืนยันจากนั้นยอดเงินของคุณจะเพิ่มขึ้นโดยอัตโนมัติ หลังจากที่แอดมินตรวจสอบ</p>
               
			   <?php foreach ($this->user_model->view_asset() as $row): ?>
					<?php if(!empty($row['rekening'])): ?>
			<p class="text-default" align="center"> <?= $row['pemilik']?><br>
		      ชำระค่าบริการให้ : 
	        <?= $row['rekening']?> <br>  <?= $row['bank']?></p>
					<?php endif; ?>					
			   <?php endforeach; ?>
	  </div>
           <div class="col-sm-6">
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($message)) : ?>
					<div class="col-md-12">
						<div class="alert alert-success" role="alert"><?= $message ?></div>
					</div>
					<?php endif;?>
			   <?= form_open() ?>
					<div class="form-group">
						<label for="sender">เบอร์ที่โอนเงิน</label>
					  <input type="text" name="sender" class="form-control" id="sender" placeholder="ระบุเบอร์ที่โอนเงินมา"/>
						
					</div>
					<div class="form-group">
						<label for="username">ชื่อบัญชี</label>
						<input type="text" name="username" class="form-control" id="username" placeholder="บัญชีที่สมัคร"/>
						
			 </div>
					<div class="form-group">
						<label for="rekening">โอนมาที่เบอร์</label>
						<select name="rekening" id="hp" class="form-control">
							<?php foreach ($this->user_model->view_asset() as $row): ?>
							<?php if(!empty($row['rekening'])): ?>
							<option value="<?= $row['rekening']?>"><?= $row['rekening'].' ('.$row['pemilik'].')'?></option>
							<?php endif; ?>	
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group">
						<label for="hp">จำนวนเงิน</label>
						<input type="number" name="jumlah" class="form-control" id="jumlah" value="10" />
						<small class="text-muted">ใส่จำนวนเงินที่โอน</small>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary form-control" value="แจ้งชำระ"/>
					</div>
			   </form>
            </div>
    </div>
</div>

<div class="footer">
	<p>© 2017 TAOTATO. All Rights Reserved | Design by <a href = "https://www.facebook.com/messages/t/t4o.it" target = "_blank">TAO</a></p>
</div>
    <script src="../asset/js/sb-admin-2.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
</body>
</html>
