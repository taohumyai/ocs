<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header" onmouseover="sortTable()">Inbox</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="myTable">
                            <thead onmouseover="sortTable()">
                                <tr>
                                    <th>Id</th>
                                    <th>From</th>
                                    <th>Message</th>
                                    <th>Created</th>
                                    <th>Act</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($msg) !== 0): ?>
                                        <?php foreach ($msg as $row): ?>
                                        <tr>
                                                <td><?= $row['userid'] ?></td>
                                                <td><?= $row['username'] ?></td>
                                                <td><?= $row['pesan']?></td>
                                                <td><?= $row['created_at']?></td>
                                                <td>
                                                    <a href="<?= base_url('admin/konfirm_msg/').$row['id']?>" class="btn btn-info"> Confirm</a>
                                                </td>
                                                <td>
                                                    <a href="<?= base_url('admin/del_msg/').$row['id'] ?>" class="btn btn-danger"> Del</a>
                                                </td>
                                             </tr>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="6"> No Notify</td>
                                        </tr>
                                   <?php endif; ?>
                            </tbody>
                        </table>
<script>
function sortTable() {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("myTable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.getElementsByTagName("TR");
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[0];
      y = rows[i + 1].getElementsByTagName("TD")[0];
      //check if the two rows should switch place:
      if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
        //if so, mark as a switch and break the loop:
        shouldSwitch= true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
