<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">SSH User List
            
<a href="/admin/delete_seller" class="btn btn-default pull-right" alt="hapus seller dengan saldo 0"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete Seller </a>
</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> Seller List
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Seller</th>
                                    <th>Email</th>
                                    <th>Money</th>
                                    <th>Reg</th>
                                    <th>Del</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($msg)): ?>
                                        <?php foreach ($msg as $row): ?>
                                            <tr>
                                                <td><?= $row['id'] ?></td>
                                                <td><?= $row['username'] ?></td>
                                                <td><?= $row['email']?></td>
												<td><?= $row['saldo']?></td>
                                                <td><?= $row['created_at']?></td>
                                                
                                                <td>
                                                    <a href="<?= base_url('admin/delet_seller/'. $row['id'])?>" class="btn btn-default"><span class="fa fa-trash-o fa-sm"></span></a>
                                                </td>
                                             </tr>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="6"> No Seller</td>
                                        </tr>
                                   <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
