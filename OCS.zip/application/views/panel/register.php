<?php defined('BASEPATH'); ?>
<div class="container">
	<div class="row">
		<div class="col-lg-10">
			<div class="panel panel-default">
				<div class="panel-heading"></div>
				<div class="panel-body">
				<?php if (validation_errors()) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?= validation_errors() ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if (isset($error)) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?= $error ?>
				</div>
			</div>
		<?php endif; ?>
		<div class="col-md-12">
			<div class="page-header">
				<h1>ลงทะเบียน</h1>
			</div>
			<?= form_open() ?>
				<div class="form-group">
					<label for="username">ชื่อผู้ใช้</label>
					<input type="text" class="form-control" id="username" name="username" placeholder="Username">
					<p class="help-block">มีตัวอักษรหรือตัวเลขอย่างน้อย 4 ตัว</p>
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
					<p class="help-block">
ที่อยู่อีเมลที่ถูกต้อง</p>
				</div>
				<div class="form-group">
					<label for="password">ป้อนรหัสผ่าน</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="Enter a password">
					<p class="help-block">อย่างน้อย 6 ตัวอักษร</p>
				</div>
				<div class="form-group">
					<label for="password_confirm">ยืนยันรหัสผ่าน</label>
					<input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="Confirm your password">
					<p class="help-block">ใส่รหัสผ่านอีกครั้ง</p>
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-info" value="ยืนยัน">
				</div>
			</form>
		</div>
				</div>
				<div class="panel-footer"></div>
			</div>
		</div>
	</div><!-- .row -->
</div><!-- .container -->

<div class="footer">
	<p>© 2017 TAOTATO. All Rights Reserved | Design by <a href = "https://www.facebook.com/messages/t/t4o.it" target = "_blank">TAO</a></p>
</div>
    <script src="../asset/js/sb-admin-2.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
</body>
</html>
