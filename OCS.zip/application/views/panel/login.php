<style>Body{background-image:url(https://www.mx7.com/i/077/WTIGtF.jpg);background-position: center;background-repeat: no-repeat;background-attachment: fixed;background-color: color code;}</style>
<?
define("BASEPATH",true);
include("/panel/register.php");
?>
<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bootstrap Login Form Template</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
                            <center><h1><strong>4G-2U ยินดีต้อนรับ</strong></h1></center>
                            <center><div class="description">
                            	<p>
	                            	หากท่านกำลังประสบปัญหาเน็ตช้า เรามีทางออกมาเสนอ</p>                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                        	<div class="form-top">
                        	  <div class="form-top-left">
                       			  <center><h3>กรุณาล็อคอิน
                        		</h3>
                        		</div>
                        	</div>
                           <div class="panel-body">
						

                        <?= form_open() ?>
                            <fieldset>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user-secret fa-fw"></i></span>
                                        <input class="form-control" placeholder="ชื่อผู้ใช้งาน" name="username" type="text" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock fa-fw"></i></span>
                                        <input class="form-control" placeholder="รหัสผ่าน" name="password" type="password" required>
                              </div>                             
        <div class="field-group">
		<div><input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />
		<label for="remember-me">จดจำฉันไว้</label>
	</div>
                                </div>
                               <button class="btn btn-info btn-block btn-flat"><i class="fa fa-user fa-fw" aria-hidden="true"></i> ล็อกอิน</font></button>
                                                                   
   <a href="/panel/register" class="btn btn-danger animated flash btn-block" id="idEULA" role="button" data-toggle="modal"><i class="fa fa-pencil fa-fw" aria-hidden="true"></i> สมัครสมาชิก</a>

			                    </form>
		                    </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        	<center><h3>ติดต่อเรา</h3>
                        	<div class="social-login-buttons">
	                        	<center><h3><a class="btn btn-link-1 btn-link-1-facebook" href="https://www.facebook.com/T4O.iT" target = "_blank">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	
	                        	</a>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <center><div class="footer">
	<p>© 2017 TAOTATO. All Rights Reserved | Design by <a href = "https://www.facebook.com/messages/t/t4o.it" target = "_blank">TAO</a></p>
</div>
    <script src="../asset/js/sb-admin-2.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
</body>
</html></center>


        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>