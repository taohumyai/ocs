OcsPanel Reborns
=========
Simple and mudah, 100% free.
Panel ini adalah pengembangan dari ide ocs panel meskipun dari segi source sangat jauh berbeda dimana panel ini menggunakan codignither sebagai enginenya.
Features
-------
* **Sistem Deposit** : Seller cukup Deposit, sudah bisa create Account SSH sendiri.
* ** cek account**: seler dapat melihat akun yg dibuat serta menghapusnya
* ** SSH2** : Menggunakan modul ssh2, tanpa dipasang webmin pun layanan ini deapat bekerja dengan baik.
* ** Public server** : menu public server. (nb: fitur ini masih dalam tahap pengembangan)

Requirements
---------

##### Hosting
* PHP versi 5.4 keatas.
* MySQL versi 5.0.0 keatas.


Installation
------------
1. Upload / Hosting ke Cpanel / VPS yang sudah diinstall WebServer.
2. Buat Database di MySQL.
3. Masuk ke `http://*domainmu_atau_ip_VPS*/install
4. Setelah selesai hapus folder `install demi keamanan`.

Contributing
------------
Jika menemukan masalah silahkan *Create Issue* & *Pull Request*.
atau inbok ke https://www.facebook.com/adipati.aarya

Creadits
--------

Moral Donations
---------
* paypal aryaadipati2@gmail.com
* BCA 842 031 3561
Copyright & License
------------
Copyright (c) 2017 Adipati Arya 
[GNU Public License](http://www.gnu.org/licenses/gpl-3.0.html)
